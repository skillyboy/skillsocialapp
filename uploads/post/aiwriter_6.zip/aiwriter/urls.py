"""Expense URL Configuration

The `urlpatterns` list routes URLs to views. For more information please see:
    https://docs.djangoproject.com/en/3.1/topics/http/urls/
Examples:
Function views
    1. Add an import:  from my_app import views
    2. Add a URL to urlpatterns:  path('', views.home, name='home')
Class-based views
    1. Add an import:  from other_app.views import Home
    2. Add a URL to urlpatterns:  path('', Home.as_view(), name='home')
Including another URLconf
    1. Import the include() function: from django.urls import include, path
    2. Add a URL to urlpatterns:  path('blog/', include('blog.urls'))
"""
from django.contrib import admin
from django.urls import path
from .views import *
from django.views.decorators.csrf import csrf_exempt


urlpatterns = [
path("",aiwriter),
#path("content/", content),
path("cold-email/", coldEmail),
path("facebook-ads/", facebookAds),
path("googleads/", googleAds),
path("facebook-post/", facebookPost),
path("instagram-caption/", instagramCaption),
path("Linkedin-post/", linkedinPost),
path("Pinterest-pin/", pinterestPin),
path("promotional-email/", promotionalEmail),
path("promotional-sms/", promotionalSms),
path("tweet/", tweet),
path("twitterAds/", twitterAds),
path("Youtube-description/", YoutubeDescription),
path("twitterAds/rewrite/", rewrite),
path("twitterAds/PowerMode/", PowerMode),
path("twitterAds/rewrite-headline/", RewriteHeadline),
path("twitterAds/powerMode-headline/",PowerModeHeadine),
path("twitterAds/template-headline/",templateHeadine),
path("twitterAds/whiteboard/",whiteboard),
path("twitterAds/template/",template)

#path("saved/", Saved),
]



