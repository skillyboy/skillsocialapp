from django.apps import AppConfig


class AiwriterConfig(AppConfig):
    default_auto_field = 'django.db.models.BigAutoField'
    name = 'aiwriter'
