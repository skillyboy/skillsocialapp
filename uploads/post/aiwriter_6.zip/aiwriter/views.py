from django.http import HttpResponseRedirect
from django.shortcuts import render, redirect, HttpResponse
import os
import openai

openai.api_key = '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'

# Create your views here.

def aiwriter(request):
    return render(request, 'aiwriter.html')


def generateBlogTopics(prompt):
    response = openai.Completion.create(
        engine="text-davinci-002",
         prompt="Please write a perfect blog idea and a relevant outline for the “Primary Keyword” given.\n\nPrimary Keyword: {}".format(prompt),
        temperature=0.8,
        max_tokens=256,
        top_p=1,
        frequency_penalty=0,
        presence_penalty=0
    )
    
    return response['choices'][0]['text']


def coldEmail(request):
    return render(request, 'cold-email.html')

def facebookAds(request):
    return render(request, 'facebook-ads.html')

def facebookPost(request):
    return render(request, 'facebook-post.html')

def googleAds(request):
    return render(request, 'googleadsr.html')

def instagramCaption(request):
    return render(request, 'instagram-caption.html')

def linkedinPost(request):
    return render(request, 'Linkedin-post.html')

def pinterestPin(request):
    return render(request, 'Pinterest-pin.html')

def promotionalEmail(request):
    return render(request, 'promotional-email.html')

def promotionalSms(request):
    return render(request, 'promotional-sms.html')

def tweet(request):
    return render(request, 'tweet.html')

def twitterAds(request):
    return render(request, 'twitterAds.html')

def YoutubeDescription(request):
    return render(request, 'Youtube-description.html')

def rewrite(request):
    return render(request,'rewrite.html')

def PowerMode(request):
    return render(request,'PowerMode.html')

def RewriteHeadline(request):
    return render(request,'rewrite-headline.html')

def PowerModeHeadine(request):
    return render(request,'powerMode-headline.html')

def templateHeadine(request):
    return render(request,'template-headline.html')

def whiteboard(request):
    return render(request,'whiteboard.html')

def template(request):
    return render(request,'template.html')